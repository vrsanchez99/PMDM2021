package com.example.ahorcado_victorruiz;

public class test {
    public static void main(String[] args) {
        String s = "- - - - - ";
        System.out.println(s.indexOf(2));
    }
}
